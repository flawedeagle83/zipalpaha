package com.textfilereader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Class to read in a text file and parse the lines in it, then classify, filter
 * and sort them out. Single word lines will go in one list of data and
 * multi-word lines will go into another. Each list will be sorted. Single line
 * lists will be sorted with alphabateic order and multi-word lines will be
 * sorted with length. In multi-word line list, same length lines will be sorted
 * in alphabetic order. filterring process will remove duplicates. While
 * removing duplicates, case-sensitivity can be truned on or off.
 */
public class TextFileReader {

    private boolean caseSensitive;
    private ArrayList<String> data;
    private ArrayList<String> singleWordLines;
    private ArrayList<String> multiWordLines;

    /**
     * Constructs a new text file reader.
     */
    public TextFileReader() {
        data = new ArrayList<String>();
        singleWordLines = new ArrayList<String>();
        multiWordLines = new ArrayList<String>();
    }

    /**
     * enable case sensitivity.
     * 
     * @param caseSensitive the case sensitivity to set
     */
    public void setCaseSensitive(boolean caseSensitive) {
        this.caseSensitive = caseSensitive;
    }

    /**
     * check if case-sensitivity is turned on or off.
     * 
     * @return the case sensitivity
     */
    public boolean isCaseSensitive() {
        return caseSensitive;
    }

    /**
     * Getter method for filtered and sorted single word lines.
     * 
     * @return the singleWordLines
     */
    public List<String> getSingleWordLines() {
        return singleWordLines;
    }

    /**
     * Getter method for filtered and sorted multi-word lines/phrases.
     * 
     * @return the multiWordLines
     */
    public List<String> getMultiWordLines() {
        return multiWordLines;
    }

    /**
     * Read data from file located at the given file path. This method only reads in
     * the data line by line and stores internally for further processing.
     * 
     * @param filePath file path
     * 
     * @return <code>true</code> if succeed
     */
    public boolean readData(String filePath) {
        boolean rv = true;
        try {
            rv = readData(new FileReader(filePath));
        } catch (Exception e) {
            // TODO: should we use logger instead of console printing
            System.out.println("ERROR: " + e.getMessage());

            return false;
        }
        return rv;
    }

    /**
     * Read data from file located at the given file path. This method only reads in
     * the data line by line and stores internally for further processing.
     * 
     * @param reader <code>io.Reader</code> instance.
     * 
     * @return <code>true</code> if succeed
     */
    public boolean readData(Reader reader) {
        try {
            BufferedReader fileReader = new BufferedReader(reader);

            // clear previous data
            data.clear();

            // read file line by line
            String line;
            do {
                line = fileReader.readLine();
                if (line != null) {
                    line = line.trim();
                    if(!line.isEmpty()) {
                        data.add(line);
                    }
                }
            } while (line != null);

            // must close the stream after reading is done
            fileReader.close();
        } catch (Exception e) {
            // TODO: should we use logger instead of console printing
            System.out.println("ERROR: " + e.getMessage());

            return false;
        }
        return true;
    }

    /**
     * Method to filter the internal data set with case sensitivity turned on.
     */
    private void filterCaseSensitive() {
        // we use a hash set to keep only unique values
        Set<String> filterStrings = new HashSet<>(data);
        data.clear();
        data.addAll(filterStrings);
    }

    /**
     * Method to filter the internal data set with case sensitivity turned off.
     */
    private void filterCaseInsensitive() {
        // using a map to keep case insensitive uniques
        Map<String, String> map = new HashMap<>();
        for (String line : data) {
            map.put(line.toUpperCase(), line);
        }

        data.clear();
        data.addAll(map.values());
    }

    /**
     * Method to filter the internal data set.
     */
    public void filterData() {
        if (isCaseSensitive()) {
            filterCaseSensitive();
        } else {
            filterCaseInsensitive();
        }
    }

    /**
     * Process the internal data set. This method will separate the single word
     * lines from multi-word lines and put them in separate lists. The internal
     * separated lists will be valid and availabel after calling this method. This
     * method does not sort the separated lists.
     */
    public void processData() {
        // clear previous data
        singleWordLines.clear();
        multiWordLines.clear();

        for (String line : data) {
            boolean multiWord = false;
            for (char ch : line.toCharArray()) {
                if (Character.isWhitespace(ch)) { // if whitespace is present consider the line having more than on word
                    multiWord = true;
                    break;
                }
            }

            if (multiWord) {
                multiWordLines.add(line);
            } else {
                singleWordLines.add(line);
            }
        }
    }

    /**
     * Sort the single word lines in alphabetic order. This sorting only considers
     * the first character. so "abc" might come after "acb".
     */
    public void sortSingleWordLines() {
        for (int ix = 0; ix < singleWordLines.size() - 1; ix++) {
            for (int jx = 0; jx < singleWordLines.size() - 1; jx++) {
                String line1 = singleWordLines.get(jx);
                String line2 = singleWordLines.get(jx + 1);
                if (Character.toUpperCase(line2.charAt(0)) < Character.toUpperCase(line1.charAt(0))) {
                    singleWordLines.set(jx + 1, line1);
                    singleWordLines.set(jx, line2);
                }
            }
        }
    }

    /**
     * Sort the multi-word lines in size and then alphabetic order(in case of same
     * alphabet). Alphabetic sorting only considers the first character.
     */
    public void sortMultiWordLines() {
        for (int ix = 0; ix < multiWordLines.size() - 1; ix++) {
            for (int jx = 0; jx < multiWordLines.size() - 1; jx++) {
                String line1 = multiWordLines.get(jx);
                String line2 = multiWordLines.get(jx + 1);
                if (line2.length() < line1.length()) {
                    multiWordLines.set(jx + 1, line1);
                    multiWordLines.set(jx, line2);
                    continue;
                }
                if ((line2.length() == line1.length())
                        && (Character.toUpperCase(line2.charAt(0)) < Character.toUpperCase(line1.charAt(0)))) {
                    multiWordLines.set(jx + 1, line1);
                    multiWordLines.set(jx, line2);
                }
            }
        }
    }

    /**
     * Short-hand method to read, process and sort data sets from a file located at
     * given file path.
     * 
     * @param filePath file path
     * @return <code>true</code> if succeed
     */
    public boolean readAndProcess(String filePath) {

        if (!readData(filePath)) {
            return false;
        }

        performProcessing();

        return true;
    }

    /**
     * Short-hand method to read, process and sort data sets from a reader instance.
     * 
     * @param reader <code>io.Reader</code> instance
     * @return <code>true</code> if succeed
     */
    public boolean readAndProcess(Reader reader) {

        if (!readData(reader)) {
            return false;
        }

        performProcessing();

        return true;
    }

    /**
     * Method to perform all the processing in sequence.
     */
    private void performProcessing() {
        // filter
        filterData();

        // process
        processData();

        // sort
        sortSingleWordLines();
        sortMultiWordLines();
    }
}