package com.textfilereader;

import java.util.List;

/**
 * ExampleApp
 */
public class ExampleApp {

    public static void main(String[] args) {
        if (args.length < 1) {
            // print usage
            System.out.println("usage: \njava  -jar <full_jar_file_path> <input_file_path>");
        }

        String filePath = args[0];
        TextFileReader reader = new TextFileReader();
        System.out.println("** Reading " + filePath + "...");
        if (!reader.readAndProcess(filePath)) {
            System.out.println("** Failed to read the specified file!");
            return;
        }

        List<String> singleWordLines = reader.getSingleWordLines();
        List<String> multiWordLines = reader.getMultiWordLines();

        System.out.println("** Single Word Lines -");
        int count = 0;
        for (String line : singleWordLines) {
            System.out.println("    " + count + ": " + line);
            count++;
        }
        System.out.println();

        System.out.println("** Multi Word Lines -");
        count = 0;
        for (String line : multiWordLines) {
            System.out.println("    " + count + ": " + line);
            count++;
        }
    }
}
