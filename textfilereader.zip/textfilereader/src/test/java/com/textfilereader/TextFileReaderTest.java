package com.textfilereader;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.StringReader;
import java.util.List;

import org.junit.Test;

/**
 * TextFileReaderTest
 */
public class TextFileReaderTest {

    /**
     * Tests if reader can process LF (unix newline) file stream with case
     * sensitivity turned off.
     */
    @Test
    public void shouldProcessLFDataCaseInsensitive() {
        StringReader reader = new StringReader("a\nc\nA\nab ab\nabc abc\nbd bd\n");
        TextFileReader tReader = new TextFileReader();
        assertTrue("should be able to read from a LF separated string data set", tReader.readAndProcess(reader));
        List<String> singleWordLines = tReader.getSingleWordLines();
        List<String> multiWordLines = tReader.getMultiWordLines();

        assertEquals("single word lines should have 2 values", singleWordLines.size(), 2);
        assertEquals("multi word lines should have 3 values", multiWordLines.size(), 3);

        assertEquals(singleWordLines.get(0), "A");
        assertEquals(singleWordLines.get(1), "c");
    }

    /**
     * Tests if the reader can process LF file streams with case sensitivity turned
     * on.
     */
    @Test
    public void shouldProcessLFDataCaseSensitive() {
        StringReader reader = new StringReader("a\nc\nA\nab ab\nabc abc\nbd bd\n");
        TextFileReader tReader = new TextFileReader();
        tReader.setCaseSensitive(true);
        assertTrue("should be able to read from a LF separated string data set", tReader.readAndProcess(reader));
        List<String> singleWordLines = tReader.getSingleWordLines();
        List<String> multiWordLines = tReader.getMultiWordLines();

        assertEquals("single word lines should have 3 values", singleWordLines.size(), 3);
        assertEquals("multi word lines should have 3 values", multiWordLines.size(), 3);

        assertEquals(singleWordLines.get(0), "a");
        assertEquals(singleWordLines.get(1), "A");
    }

    /**
     * tests if reader can process CRLF based streams with case sensitivity turned
     * off.
     */
    @Test
    public void shouldProcessCRLFDataCaseInsensitive() {
        StringReader reader = new StringReader("a\r\nc\r\nA\r\nab ab\r\nabc abc\r\nbd bd\r\n");
        TextFileReader tReader = new TextFileReader();
        assertTrue("should be able to read from a LF separated string data set", tReader.readAndProcess(reader));
        List<String> singleWordLines = tReader.getSingleWordLines();
        List<String> multiWordLines = tReader.getMultiWordLines();

        assertEquals("single word lines should have 2 values", singleWordLines.size(), 2);
        assertEquals("multi word lines should have 3 values", multiWordLines.size(), 3);

        assertEquals(singleWordLines.get(0), "A");
        assertEquals(singleWordLines.get(1), "c");
    }

    /**
     * Tests if reader can process CRLF based streams with case sensitivity turned
     * on.
     */
    @Test
    public void shouldProcessCRLFDataCaseSensitive() {
        StringReader reader = new StringReader("a\r\nc\r\nA\r\nab ab\r\nabc abc\r\nbd bd\r\n");
        TextFileReader tReader = new TextFileReader();
        tReader.setCaseSensitive(true);
        assertTrue("should be able to read from a LF separated string data set", tReader.readAndProcess(reader));
        List<String> singleWordLines = tReader.getSingleWordLines();
        List<String> multiWordLines = tReader.getMultiWordLines();

        assertEquals("single word lines should have 3 values", singleWordLines.size(), 3);
        assertEquals("multi word lines should have 3 values", multiWordLines.size(), 3);

        assertEquals(singleWordLines.get(0), "a");
        assertEquals(singleWordLines.get(1), "A");
    }

    /**
     * tests if reader can avoid empty lines in the data stream.
     */
    @Test
    public void shouldAvoiEmptyLine() {
        StringReader reader = new StringReader("a\r\n  \t\r\nc\r\nA\r\nab ab\r\nabc abc\r\nbd bd\r\n");
        TextFileReader tReader = new TextFileReader();
        tReader.setCaseSensitive(true);
        assertTrue("should be able to read from a LF separated string data set", tReader.readAndProcess(reader));
        List<String> singleWordLines = tReader.getSingleWordLines();

        assertEquals("single word lines should have 3 values", singleWordLines.size(), 3);
    }

    /**
     * tests if same sized lines in multi-word lines in alphabetic order.
     */
    @Test
    public void shouldSortMultiSameSizedAlphabetically() {
        StringReader reader = new StringReader("a\r\n  \t\r\nc\r\nA\r\nab ab\r\nabc abc\r\nbd bd\r\n");
        TextFileReader tReader = new TextFileReader();
        tReader.setCaseSensitive(true);
        assertTrue("should be able to read from a LF separated string data set", tReader.readAndProcess(reader));
        List<String> multiWordLines = tReader.getMultiWordLines();

        assertEquals(multiWordLines.size(), 3);
        assertEquals(multiWordLines.get(0), "ab ab");
        assertEquals(multiWordLines.get(1), "bd bd");
    }
}